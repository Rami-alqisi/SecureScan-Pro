import json
from datetime import datetime

def export_json(results, target):
    filename = f"scan_report_{target}.json"

    report = {
        "target": target,
        "scan_time": str(datetime.now()),
        "open_ports": results
    }

    with open(filename, "w") as f:
        json.dump(report, f, indent=4)

    print(f"\n📁 Report saved as {filename}")
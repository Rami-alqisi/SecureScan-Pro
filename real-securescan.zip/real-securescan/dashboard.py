import streamlit as st
import socket
import requests
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import matplotlib.pyplot as plt

# ===============================
# CONFIG
# ===============================

NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
API_KEY = "b8ef2f05-30b2-49b1-88e9-bcc13bec3d49"

st.set_page_config(page_title="SecureScan Pro", layout="wide")
st.title("🔐 SecureScan Pro - Live Scanner Dashboard")

# ===============================
# CVE LOOKUP
# ===============================

def search_cves(service_name):
    if not service_name or service_name == "Unknown":
        return []

    headers = {"apiKey": API_KEY}
    params = {
        "keywordSearch": service_name,
        "resultsPerPage": 3
    }

    try:
        response = requests.get(NVD_API, headers=headers, params=params, timeout=10)
        if response.status_code != 200:
            return []

        data = response.json()
        cves = []

        for item in data.get("vulnerabilities", []):
            cve_data = item["cve"]
            cve_id = cve_data["id"]
            description = cve_data["descriptions"][0]["value"]

            metrics = cve_data.get("metrics", {})
            cvss_score = "N/A"

            if "cvssMetricV31" in metrics:
                cvss_score = metrics["cvssMetricV31"][0]["cvssData"]["baseScore"]

            severity = "Unknown"
            if isinstance(cvss_score, (int, float)):
                if cvss_score >= 9:
                    severity = "Critical"
                elif cvss_score >= 7:
                    severity = "High"
                elif cvss_score >= 4:
                    severity = "Medium"
                else:
                    severity = "Low"

            cves.append({
                "cve_id": cve_id,
                "description": description[:200],
                "cvss_score": cvss_score,
                "severity": severity
            })

        return cves

    except:
        return []

# ===============================
# BANNER GRAB
# ===============================

def grab_banner(ip, port):
    try:
        sock = socket.socket()
        sock.settimeout(2)
        sock.connect((ip, port))
        banner = sock.recv(1024).decode(errors="ignore").strip()
        sock.close()
        return banner if banner else "Unknown"
    except:
        return "Unknown"

# ===============================
# PORT SCAN
# ===============================

def scan_port(ip, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((ip, port))

        if result == 0:
            banner = grab_banner(ip, port)
            cves = search_cves(banner)
            return {
                "port": port,
                "banner": banner,
                "cves": cves
            }

        sock.close()
    except:
        pass

    return None

# ===============================
# UI
# ===============================

target = st.text_input("Target IP", "127.0.0.1")
start_port = st.number_input("Start Port", 1, 65535, 1)
end_port = st.number_input("End Port", 1, 65535, 100)

if st.button("🚀 Start Scan"):

    results = []

    st.info(f"Scanning {target} from {start_port} to {end_port}...")

    with ThreadPoolExecutor(max_workers=100) as executor:
        futures = [
            executor.submit(scan_port, target, port)
            for port in range(start_port, end_port + 1)
        ]

        for future in futures:
            result = future.result()
            if result:
                results.append(result)

    if not results:
        st.warning("No open ports found.")
    else:
        st.success(f"Found {len(results)} open ports.")

        severity_list = []
        for r in results:
            for cve in r["cves"]:
                severity_list.append(cve["severity"])

        if severity_list:
            counter = Counter(severity_list)
            fig = plt.figure()
            plt.pie(counter.values(), labels=counter.keys(), autopct='%1.1f%%')
            plt.title("CVE Severity Distribution")
            st.pyplot(fig)

        st.divider()

        for port in results:
            with st.expander(f"🔌 Port {port['port']} - {port['banner']}"):
                if port["cves"]:
                    for cve in port["cves"]:
                        severity = cve["severity"]
                        text = f"{cve['cve_id']} | CVSS: {cve['cvss_score']} | {severity}"

                        if severity == "Critical":
                            st.error(text)
                        elif severity == "High":
                            st.warning(text)
                        elif severity == "Medium":
                            st.info(text)
                        else:
                            st.success(text)

                        st.write(cve["description"])
                        st.divider()
                else:
                    st.success("✅ No CVEs Found")
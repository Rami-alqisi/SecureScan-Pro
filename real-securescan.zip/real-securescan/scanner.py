import socket
from concurrent.futures import ThreadPoolExecutor
from colorama import Fore, init
from utils import grab_banner
from reporter import export_json
from cve_lookup import search_cves

init()

open_ports = []

def scan_port(ip, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((ip, port))

        if result == 0:
            banner = grab_banner(ip, port)
            cves = search_cves(banner)

            print(Fore.GREEN + f"[OPEN] Port {port} | Service: {banner}")

            open_ports.append({
                "port": port,
                "banner": banner,
                "cves": cves
            })

        sock.close()
    except:
        pass

def main():
    target = input("Enter target IP: ")
    start_port = int(input("Start Port: "))
    end_port = int(input("End Port: "))

    print(f"\n🔍 Scanning {target} from {start_port} to {end_port}...\n")

    with ThreadPoolExecutor(max_workers=100) as executor:
        for port in range(start_port, end_port + 1):
            executor.submit(scan_port, target, port)

    export_json(open_ports, target)

if __name__ == "__main__":
    main()
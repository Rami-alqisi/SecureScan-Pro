import requests

NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
API_KEY = "b8ef2f05-30b2-49b1-88e9-bcc13bec3d49"

def search_cves(service_name):
    if not service_name or service_name == "Unknown":
        return []

    headers = {
        "apiKey": API_KEY
    }

    params = {
        "keywordSearch": service_name,
        "resultsPerPage": 5
    }

    try:
        response = requests.get(
            NVD_API,
            headers=headers,
            params=params,
            timeout=10
        )

        if response.status_code != 200:
            return []

        data = response.json()
        cves = []

        for item in data.get("vulnerabilities", []):
            cve_data = item["cve"]

            cve_id = cve_data["id"]
            description = cve_data["descriptions"][0]["value"]

            metrics = cve_data.get("metrics", {})
            cvss_score = "N/A"

            if "cvssMetricV31" in metrics:
                cvss_score = metrics["cvssMetricV31"][0]["cvssData"]["baseScore"]

            severity = "Unknown"
            if isinstance(cvss_score, (int, float)):
                if cvss_score >= 9:
                    severity = "Critical"
                elif cvss_score >= 7:
                    severity = "High"
                elif cvss_score >= 4:
                    severity = "Medium"
                else:
                    severity = "Low"

            cves.append({
                "cve_id": cve_id,
                "description": description[:200],
                "cvss_score": cvss_score,
                "severity": severity
            })

        return cves

    except:
        return []